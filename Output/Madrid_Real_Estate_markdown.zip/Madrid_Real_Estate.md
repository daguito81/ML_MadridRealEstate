
# Madrid Real Estate - Linear Regression Project

## MDB 2018 - O2 - H

#### First we import libraries we will need


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline
```


```python
import warnings
warnings.filterwarnings('ignore')
import os
import time
```

#### We then import the data that was cleaned using Dataiku as per the attached document


```python
df = pd.read_csv("./Data/idealista_data_V2_prepared.csv")
```


```python
df.head() #We check the head of the dataframe to make sure everything seems ok
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>address</th>
      <th>bathrooms</th>
      <th>country</th>
      <th>detailedType_typology</th>
      <th>detailedType_subTypology</th>
      <th>distance</th>
      <th>district</th>
      <th>exterior</th>
      <th>externalReference</th>
      <th>floor</th>
      <th>...</th>
      <th>province</th>
      <th>rooms</th>
      <th>showAddress</th>
      <th>size</th>
      <th>status</th>
      <th>suggestedTexts_subtitle</th>
      <th>suggestedTexts_title</th>
      <th>thumbnail</th>
      <th>url</th>
      <th>geopoint</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>calle de San Restituto, 14</td>
      <td>1</td>
      <td>es</td>
      <td>flat</td>
      <td>NaN</td>
      <td>5370</td>
      <td>Moncloa</td>
      <td>True</td>
      <td>NaN</td>
      <td>3</td>
      <td>...</td>
      <td>Madrid</td>
      <td>1</td>
      <td>True</td>
      <td>42.0</td>
      <td>good</td>
      <td>Valdezarza, Madrid</td>
      <td>Piso en calle de San Restituto, 14</td>
      <td>https://img3.idealista.com/blur/WEB_LISTING/0/...</td>
      <td>https://www.idealista.com/inmueble/39665037/</td>
      <td>POINT(-3.7107396 40.4646941)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>saliente</td>
      <td>4</td>
      <td>es</td>
      <td>chalet</td>
      <td>independantHouse</td>
      <td>12096</td>
      <td>Urbanizaciones</td>
      <td>False</td>
      <td>NaN</td>
      <td>0</td>
      <td>...</td>
      <td>Madrid</td>
      <td>4</td>
      <td>False</td>
      <td>375.0</td>
      <td>good</td>
      <td>Montealina, Pozuelo de Alarcón</td>
      <td>Casa independiente en saliente</td>
      <td>https://img3.idealista.com/blur/WEB_LISTING/0/...</td>
      <td>https://www.idealista.com/inmueble/82149948/</td>
      <td>POINT(-3.8454306 40.4330817)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>calle Mallorca, 3</td>
      <td>1</td>
      <td>es</td>
      <td>flat</td>
      <td>NaN</td>
      <td>1192</td>
      <td>Centro</td>
      <td>True</td>
      <td>NaN</td>
      <td>0</td>
      <td>...</td>
      <td>Madrid</td>
      <td>3</td>
      <td>True</td>
      <td>70.0</td>
      <td>good</td>
      <td>Lavapiés-Embajadores, Madrid</td>
      <td>Piso en calle Mallorca, 3</td>
      <td>https://img3.idealista.com/blur/WEB_LISTING/0/...</td>
      <td>https://www.idealista.com/inmueble/37138962/</td>
      <td>POINT(-3.697682 40.4071354)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>calle Valmojado, 181</td>
      <td>3</td>
      <td>es</td>
      <td>flat</td>
      <td>NaN</td>
      <td>5422</td>
      <td>Latina</td>
      <td>True</td>
      <td>NaN</td>
      <td>5</td>
      <td>...</td>
      <td>Madrid</td>
      <td>3</td>
      <td>True</td>
      <td>79.0</td>
      <td>good</td>
      <td>Aluche, Madrid</td>
      <td>Piso en calle Valmojado, 181</td>
      <td>https://img3.idealista.com/blur/WEB_LISTING/0/...</td>
      <td>https://www.idealista.com/inmueble/83311256/</td>
      <td>POINT(-3.7577512 40.3899565)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>avenida donostiarra, 21</td>
      <td>2</td>
      <td>es</td>
      <td>flat</td>
      <td>NaN</td>
      <td>4326</td>
      <td>Ciudad Lineal</td>
      <td>True</td>
      <td>NaN</td>
      <td>11</td>
      <td>...</td>
      <td>Madrid</td>
      <td>2</td>
      <td>True</td>
      <td>65.0</td>
      <td>good</td>
      <td>Concepción, Madrid</td>
      <td>Piso en avenida donostiarra, 21</td>
      <td>https://img3.idealista.com/blur/WEB_LISTING/0/...</td>
      <td>https://www.idealista.com/inmueble/31436202/</td>
      <td>POINT(-3.6587854 40.4345648)</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 39 columns</p>
</div>




```python
df.info() #We can see
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4148 entries, 0 to 4147
    Data columns (total 39 columns):
    address                     4148 non-null object
    bathrooms                   4148 non-null int64
    country                     4148 non-null object
    detailedType_typology       4148 non-null object
    detailedType_subTypology    716 non-null object
    distance                    4148 non-null int64
    district                    4148 non-null object
    exterior                    4148 non-null bool
    externalReference           2805 non-null object
    floor                       4148 non-null int64
    has360                      4148 non-null bool
    has3DTour                   4148 non-null bool
    hasLift                     4148 non-null bool
    hasPlan                     4148 non-null bool
    hasVideo                    4148 non-null bool
    latitude                    4148 non-null float64
    longitude                   4148 non-null float64
    municipality                4148 non-null object
    neighborhood                3990 non-null object
    newDevelopment              4148 non-null bool
    numPhotos                   4148 non-null int64
    operation                   4148 non-null object
    hasParkingSpace             1387 non-null object
    parkingSpaceIncluded        1387 non-null object
    parkingSpacePrice           215 non-null float64
    price                       4148 non-null float64
    priceByArea                 4148 non-null float64
    propertyCode                4148 non-null float64
    propertyType                4148 non-null object
    province                    4148 non-null object
    rooms                       4148 non-null int64
    showAddress                 4148 non-null bool
    size                        4148 non-null float64
    status                      4148 non-null object
    suggestedTexts_subtitle     4148 non-null object
    suggestedTexts_title        4148 non-null object
    thumbnail                   4135 non-null object
    url                         4148 non-null object
    geopoint                    4148 non-null object
    dtypes: bool(8), float64(7), int64(5), object(19)
    memory usage: 1.0+ MB
    

We can see that there are a lot of categorical variables. These won't be the best for our regression project  
so we need to check how many unique categories and how broad they are.


```python
for col in df.columns:
    if df[col].dtype == 'O':
        print(col ,'------', df[col].dtype == 'O')
        print(df[col].nunique())
        print("========================")
```

    address ------ True
    2580
    ========================
    country ------ True
    1
    ========================
    detailedType_typology ------ True
    2
    ========================
    detailedType_subTypology ------ True
    6
    ========================
    district ------ True
    67
    ========================
    externalReference ------ True
    2548
    ========================
    municipality ------ True
    13
    ========================
    neighborhood ------ True
    162
    ========================
    operation ------ True
    1
    ========================
    hasParkingSpace ------ True
    1
    ========================
    parkingSpaceIncluded ------ True
    2
    ========================
    propertyType ------ True
    5
    ========================
    province ------ True
    1
    ========================
    status ------ True
    2
    ========================
    suggestedTexts_subtitle ------ True
    191
    ========================
    suggestedTexts_title ------ True
    2547
    ========================
    thumbnail ------ True
    3931
    ========================
    url ------ True
    3944
    ========================
    geopoint ------ True
    3741
    ========================
    

We can tell that most categorical variables might be too broad. Others are redundant (only 1 )  
So we will drop all columns that seem useless and build our regression from there

We need to check the categories that have only 1 to make sure that they are not T/F categories with NaN as flags


```python
fig, ax = plt.subplots(figsize=(18,10))
sns.heatmap(df.isnull())
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d65e14c630>




![png](output_13_1.png)


Seems like sub_Typology, externalReference, hasParkingSpace, parkingSpaceIncluded and parkingSpacePrice have a lot of nulls.  
The first 2 we might drop as they seem to be almost identifiers, has parking space we could try settin them to false.  
and drop the other 2 columns related to parking space


```python
df['hasParkingSpace'].isnull().sum()/len(df['hasParkingSpace']) # 66% of the rows are null values, we take a risk using this 
```




    0.6656219864995179




```python
df['hasParkingSpace'].fillna(False, inplace=True) #We try imputing as parkins space seems important
```


```python
col_drop = []
for col in df.columns:
    if df[col].dtype == 'O' and (df[col].nunique() == 1 or df[col].nunique() >100 or df[col].isnull().sum()/len(df[col]) > 0.5) :
        col_drop.append(col)
```


```python
col_drop.append('parkingSpacePrice') #This column is almost completely empty
col_drop
```




    ['address',
     'country',
     'detailedType_subTypology',
     'externalReference',
     'neighborhood',
     'operation',
     'parkingSpaceIncluded',
     'province',
     'suggestedTexts_subtitle',
     'suggestedTexts_title',
     'thumbnail',
     'url',
     'geopoint',
     'parkingSpacePrice']




```python
df.drop(col_drop, axis=1, inplace=True)
```


```python
for col in df.columns:
    if df[col].dtype == 'O':
        print(col ,'------', df[col].dtype == 'O')
        print(df[col].nunique())
        print("========================")
```

    detailedType_typology ------ True
    2
    ========================
    district ------ True
    67
    ========================
    municipality ------ True
    13
    ========================
    propertyType ------ True
    5
    ========================
    status ------ True
    2
    ========================
    

We this we take care of wrangling the categorical values

Now we check the rest for null values


```python
df.isnull().any().any()
```




    False



We are now ready to start exploring and finding our model features


```python
for col in df.columns:
    if df[col].dtype == 'bool':
        print(col ,'------', df[col].dtype == 'bool')
        print(df[col].nunique())
        print("========================")
```

    exterior ------ True
    2
    ========================
    has360 ------ True
    2
    ========================
    has3DTour ------ True
    2
    ========================
    hasLift ------ True
    2
    ========================
    hasPlan ------ True
    2
    ========================
    hasVideo ------ True
    2
    ========================
    newDevelopment ------ True
    1
    ========================
    hasParkingSpace ------ True
    2
    ========================
    showAddress ------ True
    2
    ========================
    

"newDevelopment" is a boolean variable with all Falses so we will also drop it


```python
df.drop('newDevelopment', axis=1, inplace=True)
```

## Exploratory Data Analisys


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bathrooms</th>
      <th>distance</th>
      <th>floor</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>numPhotos</th>
      <th>price</th>
      <th>priceByArea</th>
      <th>propertyCode</th>
      <th>rooms</th>
      <th>size</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
      <td>4.148000e+03</td>
      <td>4148.000000</td>
      <td>4148.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.706606</td>
      <td>4496.768322</td>
      <td>3.187801</td>
      <td>40.435634</td>
      <td>-3.692264</td>
      <td>22.273867</td>
      <td>1570.477097</td>
      <td>16.433703</td>
      <td>7.632915e+07</td>
      <td>2.186837</td>
      <td>104.701061</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.898776</td>
      <td>3386.085864</td>
      <td>2.772488</td>
      <td>0.032076</td>
      <td>0.043421</td>
      <td>11.602292</td>
      <td>813.890293</td>
      <td>5.707456</td>
      <td>1.815802e+07</td>
      <td>1.188949</td>
      <td>66.199236</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>22.000000</td>
      <td>-1.000000</td>
      <td>40.301089</td>
      <td>-3.880282</td>
      <td>0.000000</td>
      <td>400.000000</td>
      <td>5.000000</td>
      <td>3.021850e+05</td>
      <td>0.000000</td>
      <td>20.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.000000</td>
      <td>1927.000000</td>
      <td>1.000000</td>
      <td>40.419253</td>
      <td>-3.705716</td>
      <td>14.000000</td>
      <td>950.000000</td>
      <td>13.000000</td>
      <td>8.270398e+07</td>
      <td>1.000000</td>
      <td>60.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.000000</td>
      <td>3418.000000</td>
      <td>3.000000</td>
      <td>40.432533</td>
      <td>-3.690367</td>
      <td>21.000000</td>
      <td>1300.000000</td>
      <td>15.000000</td>
      <td>8.326503e+07</td>
      <td>2.000000</td>
      <td>87.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.000000</td>
      <td>6500.000000</td>
      <td>5.000000</td>
      <td>40.456387</td>
      <td>-3.673120</td>
      <td>28.000000</td>
      <td>1935.000000</td>
      <td>19.000000</td>
      <td>8.343392e+07</td>
      <td>3.000000</td>
      <td>127.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.000000</td>
      <td>14944.000000</td>
      <td>25.000000</td>
      <td>40.545903</td>
      <td>-3.536303</td>
      <td>94.000000</td>
      <td>4000.000000</td>
      <td>63.000000</td>
      <td>8.346855e+07</td>
      <td>9.000000</td>
      <td>565.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4148 entries, 0 to 4147
    Data columns (total 24 columns):
    bathrooms                4148 non-null int64
    detailedType_typology    4148 non-null object
    distance                 4148 non-null int64
    district                 4148 non-null object
    exterior                 4148 non-null bool
    floor                    4148 non-null int64
    has360                   4148 non-null bool
    has3DTour                4148 non-null bool
    hasLift                  4148 non-null bool
    hasPlan                  4148 non-null bool
    hasVideo                 4148 non-null bool
    latitude                 4148 non-null float64
    longitude                4148 non-null float64
    municipality             4148 non-null object
    numPhotos                4148 non-null int64
    hasParkingSpace          4148 non-null bool
    price                    4148 non-null float64
    priceByArea              4148 non-null float64
    propertyCode             4148 non-null float64
    propertyType             4148 non-null object
    rooms                    4148 non-null int64
    showAddress              4148 non-null bool
    size                     4148 non-null float64
    status                   4148 non-null object
    dtypes: bool(8), float64(6), int64(5), object(5)
    memory usage: 551.0+ KB
    

At a first glance, knowing about renting apartment. There should be a correlation between:  
Price and Size  
Price and rooms  
Price and district  
Price and having parking


```python
plt.subplots(figsize=(14,8))
sns.heatmap(df.corr())
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d6612b1be0>




![png](output_32_1.png)



```python
df.corr()['price']
```




    bathrooms          0.733046
    distance          -0.078170
    exterior           0.087460
    floor              0.068430
    has360             0.170783
    has3DTour          0.053712
    hasLift            0.113241
    hasPlan            0.293408
    hasVideo           0.128853
    latitude           0.157629
    longitude         -0.084138
    numPhotos          0.413168
    hasParkingSpace    0.236443
    price              1.000000
    priceByArea        0.138320
    propertyCode      -0.051988
    rooms              0.615577
    showAddress       -0.204833
    size               0.776695
    Name: price, dtype: float64



Seems the highest correlations are with bathrooms, hasPlan, numPhotos, rooms and size  
This could be because the more expensive places tendo to have more work into them including more information  
to the platform. The size, rooms and bathrooms are logical correlations


```python
fig, ax = plt.subplots(1,3, figsize=(18,5))
sns.scatterplot(x='size', y='price', data=df, ax=ax[0], alpha=0.5)
sns.scatterplot(x='rooms', y='price', data=df, ax=ax[1], alpha=0.5)
sns.scatterplot(x='bathrooms', y='price', data=df, ax=ax[2], alpha=0.5)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d6615526a0>




![png](output_35_1.png)



```python
fig, ax = plt.subplots(figsize=(18,5))
g = sns.boxplot(x='municipality', y='price', data=df)
g.set_xticklabels(df['municipality'].unique(),rotation=45)
```




    [Text(0,0,'Madrid'),
     Text(0,0,'Pozuelo de Alarcón'),
     Text(0,0,'La Moraleja'),
     Text(0,0,'San Fernando de Henares'),
     Text(0,0,'Boadilla del Monte'),
     Text(0,0,'Majadahonda'),
     Text(0,0,'Alcorcón'),
     Text(0,0,'Getafe'),
     Text(0,0,'Leganés'),
     Text(0,0,'Alcobendas'),
     Text(0,0,'Rivas-Vaciamadrid'),
     Text(0,0,'Coslada'),
     Text(0,0,'Las Rozas de Madrid')]




![png](output_36_1.png)


We can see that there seems to be a sizeable difference in price between the different municipalities


```python
df['district'].nunique()
```




    67




```python
9 // 2
```




    4




```python
9 % 2
```




    1




```python
fig, ax = plt.subplots(8,9, figsize=(30,30))
for i, district in enumerate(df['district'].unique()):
    row = i // 9
    col = i % 8
    g =sns.boxplot(y='price', data=df[df['district'] == district], ax = ax[row, col])
    g.set_xticklabels(district)
```


![png](output_41_0.png)


We can also see that there is a big difference between the prices of the different districts. So we will have to take  
theser into accoutn as well for our model


```python
df['numPhotos'].describe()
```




    count    4148.000000
    mean       22.273867
    std        11.602292
    min         0.000000
    25%        14.000000
    50%        21.000000
    75%        28.000000
    max        94.000000
    Name: numPhotos, dtype: float64




```python
sns.lmplot('numPhotos', 'price', data=df, height=6,aspect=2)
```




    <seaborn.axisgrid.FacetGrid at 0x1d669b7aac8>




![png](output_44_1.png)


There seems to be a positive correlation between the num of photos ina  listing and its price.  
This could be because the more expensive listincs probably use real estate agent, and to increase  
exposure they have more pictures. But this could be a spurrious correlation

### Model Building 


```python
from statsmodels.regression.linear_model import OLS
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4148 entries, 0 to 4147
    Data columns (total 24 columns):
    bathrooms                4148 non-null int64
    detailedType_typology    4148 non-null object
    distance                 4148 non-null int64
    district                 4148 non-null object
    exterior                 4148 non-null bool
    floor                    4148 non-null int64
    has360                   4148 non-null bool
    has3DTour                4148 non-null bool
    hasLift                  4148 non-null bool
    hasPlan                  4148 non-null bool
    hasVideo                 4148 non-null bool
    latitude                 4148 non-null float64
    longitude                4148 non-null float64
    municipality             4148 non-null object
    numPhotos                4148 non-null int64
    hasParkingSpace          4148 non-null bool
    price                    4148 non-null float64
    priceByArea              4148 non-null float64
    propertyCode             4148 non-null float64
    propertyType             4148 non-null object
    rooms                    4148 non-null int64
    showAddress              4148 non-null bool
    size                     4148 non-null float64
    status                   4148 non-null object
    dtypes: bool(8), float64(6), int64(5), object(5)
    memory usage: 551.0+ KB
    

We know that we have the most logical correlations between price, size, rooms and bathrooms. But there  
might alos be a relacion between each other so we will build the model with these to check their  
significance 


```python
feats = df[['size','rooms','bathrooms']]
```


```python
from sklearn.preprocessing import StandardScaler
```


```python
scaler = StandardScaler()
```


```python
feats = scaler.fit_transform(feats)
```


```python
target = df['price']
```


```python
model = OLS(target,feats)
results = model.fit()
```


```python
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.133</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.132</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   211.3</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>1.45e-127</td>
</tr>
<tr>
  <th>Time:</th>                 <td>21:55:52</td>     <th>  Log-Likelihood:    </th> <td> -36610.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.323e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4145</td>      <th>  BIC:               </th> <td>7.324e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     3</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  451.2024</td> <td>   50.958</td> <td>    8.854</td> <td> 0.000</td> <td>  351.297</td> <td>  551.108</td>
</tr>
<tr>
  <th>x2</th> <td>  -16.9535</td> <td>   41.566</td> <td>   -0.408</td> <td> 0.683</td> <td>  -98.445</td> <td>   64.539</td>
</tr>
<tr>
  <th>x3</th> <td>  231.9675</td> <td>   48.523</td> <td>    4.781</td> <td> 0.000</td> <td>  136.837</td> <td>  327.098</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>848.079</td> <th>  Durbin-Watson:     </th> <td>   0.145</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>2669.183</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.036</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.340</td>  <th>  Cond. No.          </th> <td>    3.98</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



Seems like number of rooms is not significant. So we will drop that variable


```python
feats = scaler.fit_transform(df[['size','bathrooms']])
```


```python
model = OLS(target,feats)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.133</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.132</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   317.0</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>7.81e-129</td>
</tr>
<tr>
  <th>Time:</th>                 <td>21:57:12</td>     <th>  Log-Likelihood:    </th> <td> -36610.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.322e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4146</td>      <th>  BIC:               </th> <td>7.324e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     2</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  442.7951</td> <td>   46.599</td> <td>    9.502</td> <td> 0.000</td> <td>  351.437</td> <td>  534.153</td>
</tr>
<tr>
  <th>x2</th> <td>  226.4561</td> <td>   46.599</td> <td>    4.860</td> <td> 0.000</td> <td>  135.098</td> <td>  317.814</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>849.587</td> <th>  Durbin-Watson:     </th> <td>   0.145</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>2645.969</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.041</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.313</td>  <th>  Cond. No.          </th> <td>    3.34</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



Seems like they are both significant, but we're getting a low R^2 so we'll try to add some more variables


```python
feats = scaler.fit_transform(df[['size','bathrooms','distance']])
model = OLS(target,feats)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.148</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.148</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   240.3</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>9.56e-144</td>
</tr>
<tr>
  <th>Time:</th>                 <td>21:58:15</td>     <th>  Log-Likelihood:    </th> <td> -36572.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.315e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4145</td>      <th>  BIC:               </th> <td>7.317e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     3</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  459.7384</td> <td>   46.227</td> <td>    9.945</td> <td> 0.000</td> <td>  369.109</td> <td>  550.368</td>
</tr>
<tr>
  <th>x2</th> <td>  265.6544</td> <td>   46.406</td> <td>    5.725</td> <td> 0.000</td> <td>  174.675</td> <td>  356.634</td>
</tr>
<tr>
  <th>x3</th> <td> -226.8416</td> <td>   26.112</td> <td>   -8.687</td> <td> 0.000</td> <td> -278.036</td> <td> -175.647</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>866.312</td> <th>  Durbin-Watson:     </th> <td>   0.122</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>2904.474</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.037</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.537</td>  <th>  Cond. No.          </th> <td>    3.44</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



As we set the distance as the center of Madrid, it seems like being far from the center has a negative  
effect on the rental price. This could probably be used better with the districts but we won't use them yet


```python
feats = scaler.fit_transform(df[['size','bathrooms','distance', 'numPhotos']])
model = OLS(target,feats)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.150</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.149</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   183.1</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>1.20e-144</td>
</tr>
<tr>
  <th>Time:</th>                 <td>22:00:01</td>     <th>  Log-Likelihood:    </th> <td> -36567.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.314e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4144</td>      <th>  BIC:               </th> <td>7.317e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     4</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  436.1824</td> <td>   46.785</td> <td>    9.323</td> <td> 0.000</td> <td>  344.459</td> <td>  527.906</td>
</tr>
<tr>
  <th>x2</th> <td>  253.0694</td> <td>   46.530</td> <td>    5.439</td> <td> 0.000</td> <td>  161.846</td> <td>  344.292</td>
</tr>
<tr>
  <th>x3</th> <td> -221.5733</td> <td>   26.139</td> <td>   -8.477</td> <td> 0.000</td> <td> -272.819</td> <td> -170.327</td>
</tr>
<tr>
  <th>x4</th> <td>   86.3701</td> <td>   27.544</td> <td>    3.136</td> <td> 0.002</td> <td>   32.369</td> <td>  140.371</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>912.535</td> <th>  Durbin-Watson:     </th> <td>   0.121</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>3054.301</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.092</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.592</td>  <th>  Cond. No.          </th> <td>    3.64</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



So far all our chosen features are significant in their relationship with the target variable 'price'  
but we're still only explaining 15% of the variance in y. 
Some possible correlations to price can be if the place is exterior or not, if it has a lift, if it has a parking spot  
and the floor the apartment is on. So we will aggregate all those to our model


```python
feats = scaler.fit_transform(df[['size','bathrooms','distance', 'numPhotos',
                                 'hasParkingSpace', 'exterior', 'floor','hasLift']])
model = OLS(target,feats,)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.154</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.152</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   93.86</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>7.74e-144</td>
</tr>
<tr>
  <th>Time:</th>                 <td>22:41:16</td>     <th>  Log-Likelihood:    </th> <td> -36559.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.313e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4140</td>      <th>  BIC:               </th> <td>7.318e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     8</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  448.5607</td> <td>   47.283</td> <td>    9.487</td> <td> 0.000</td> <td>  355.862</td> <td>  541.260</td>
</tr>
<tr>
  <th>x2</th> <td>  240.4219</td> <td>   47.009</td> <td>    5.114</td> <td> 0.000</td> <td>  148.259</td> <td>  332.585</td>
</tr>
<tr>
  <th>x3</th> <td> -230.3370</td> <td>   29.263</td> <td>   -7.871</td> <td> 0.000</td> <td> -287.708</td> <td> -172.966</td>
</tr>
<tr>
  <th>x4</th> <td>   73.1808</td> <td>   27.729</td> <td>    2.639</td> <td> 0.008</td> <td>   18.817</td> <td>  127.544</td>
</tr>
<tr>
  <th>x5</th> <td>   19.1471</td> <td>   30.947</td> <td>    0.619</td> <td> 0.536</td> <td>  -41.526</td> <td>   79.820</td>
</tr>
<tr>
  <th>x6</th> <td>   39.6426</td> <td>   26.653</td> <td>    1.487</td> <td> 0.137</td> <td>  -12.612</td> <td>   91.897</td>
</tr>
<tr>
  <th>x7</th> <td>    4.8519</td> <td>   26.613</td> <td>    0.182</td> <td> 0.855</td> <td>  -47.324</td> <td>   57.028</td>
</tr>
<tr>
  <th>x8</th> <td>   79.9169</td> <td>   27.387</td> <td>    2.918</td> <td> 0.004</td> <td>   26.225</td> <td>  133.609</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>999.514</td> <th>  Durbin-Watson:     </th> <td>   0.115</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>3196.133</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.212</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.551</td>  <th>  Cond. No.          </th> <td>    3.95</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



Seems like having a parking space, being exterior and which floor they're on are not significant.  
We check the reponse to floor as it might be a non linear relationship


```python
sns.scatterplot('floor', 'price', data=df, alpha=0.6)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1d669a17198>




![png](output_67_1.png)


There seems to be almost no relationship


```python
feats = scaler.fit_transform(df[['size','bathrooms','distance', 'numPhotos',
                                 'hasLift']])
model = OLS(target,feats,)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.153</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.152</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   149.6</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>2.00e-146</td>
</tr>
<tr>
  <th>Time:</th>                 <td>22:45:08</td>     <th>  Log-Likelihood:    </th> <td> -36560.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.313e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4143</td>      <th>  BIC:               </th> <td>7.316e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     5</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  452.0322</td> <td>   46.911</td> <td>    9.636</td> <td> 0.000</td> <td>  360.062</td> <td>  544.003</td>
</tr>
<tr>
  <th>x2</th> <td>  241.8610</td> <td>   46.558</td> <td>    5.195</td> <td> 0.000</td> <td>  150.582</td> <td>  333.140</td>
</tr>
<tr>
  <th>x3</th> <td> -218.4972</td> <td>   26.112</td> <td>   -8.368</td> <td> 0.000</td> <td> -269.691</td> <td> -167.303</td>
</tr>
<tr>
  <th>x4</th> <td>   77.1545</td> <td>   27.615</td> <td>    2.794</td> <td> 0.005</td> <td>   23.013</td> <td>  131.296</td>
</tr>
<tr>
  <th>x5</th> <td>   94.0462</td> <td>   25.495</td> <td>    3.689</td> <td> 0.000</td> <td>   44.063</td> <td>  144.030</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>984.412</td> <th>  Durbin-Watson:     </th> <td>   0.116</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>3159.656</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.193</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.548</td>  <th>  Cond. No.          </th> <td>    3.65</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



We're back to 100% significance, but we need to test the other boolean values for their correlation  
has360        
has3DTour   
hasLift   
hasPlan 
hasVideo


```python
feats = scaler.fit_transform(df[['size','bathrooms','distance', 'numPhotos',
                                 'hasLift', 'has360','has3DTour', 'hasLift',
                                'hasPlan', 'hasVideo']])
model = OLS(target,feats,)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.156</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.154</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   84.69</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>6.24e-145</td>
</tr>
<tr>
  <th>Time:</th>                 <td>22:52:15</td>     <th>  Log-Likelihood:    </th> <td> -36554.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.313e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4139</td>      <th>  BIC:               </th> <td>7.318e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     9</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>      <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th>  <td>  444.0775</td> <td>   46.931</td> <td>    9.462</td> <td> 0.000</td> <td>  352.067</td> <td>  536.088</td>
</tr>
<tr>
  <th>x2</th>  <td>  236.3259</td> <td>   46.548</td> <td>    5.077</td> <td> 0.000</td> <td>  145.067</td> <td>  327.585</td>
</tr>
<tr>
  <th>x3</th>  <td> -205.9304</td> <td>   26.471</td> <td>   -7.780</td> <td> 0.000</td> <td> -257.827</td> <td> -154.033</td>
</tr>
<tr>
  <th>x4</th>  <td>   60.1334</td> <td>   28.445</td> <td>    2.114</td> <td> 0.035</td> <td>    4.365</td> <td>  115.902</td>
</tr>
<tr>
  <th>x5</th>  <td>   45.5612</td> <td>   12.744</td> <td>    3.575</td> <td> 0.000</td> <td>   20.576</td> <td>   70.546</td>
</tr>
<tr>
  <th>x6</th>  <td>   66.6015</td> <td>   25.607</td> <td>    2.601</td> <td> 0.009</td> <td>   16.398</td> <td>  116.805</td>
</tr>
<tr>
  <th>x7</th>  <td>    2.7749</td> <td>   25.535</td> <td>    0.109</td> <td> 0.913</td> <td>  -47.287</td> <td>   52.837</td>
</tr>
<tr>
  <th>x8</th>  <td>   45.5612</td> <td>   12.744</td> <td>    3.575</td> <td> 0.000</td> <td>   20.576</td> <td>   70.546</td>
</tr>
<tr>
  <th>x9</th>  <td>   62.7697</td> <td>   31.462</td> <td>    1.995</td> <td> 0.046</td> <td>    1.086</td> <td>  124.453</td>
</tr>
<tr>
  <th>x10</th> <td>  -11.3108</td> <td>   29.729</td> <td>   -0.380</td> <td> 0.704</td> <td>  -69.595</td> <td>   46.974</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>834.288</td> <th>  Durbin-Watson:     </th> <td>   0.117</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>2433.558</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.045</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.117</td>  <th>  Cond. No.          </th> <td>7.82e+15</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The smallest eigenvalue is 1.59e-28. This might indicate that there are<br/>strong multicollinearity problems or that the design matrix is singular.



We see a couple of non-significant variables so we take them out 


```python
feats = scaler.fit_transform(df[['size','bathrooms','distance', 'numPhotos',
                                 'hasLift', 'has360', 'hasLift',
                                'hasPlan']])
model = OLS(target,feats,)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.155</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.154</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   108.9</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>6.20e-147</td>
</tr>
<tr>
  <th>Time:</th>                 <td>22:54:49</td>     <th>  Log-Likelihood:    </th> <td> -36554.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.312e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4141</td>      <th>  BIC:               </th> <td>7.317e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     7</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>     <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th> <td>  444.2716</td> <td>   46.911</td> <td>    9.471</td> <td> 0.000</td> <td>  352.302</td> <td>  536.242</td>
</tr>
<tr>
  <th>x2</th> <td>  236.1096</td> <td>   46.535</td> <td>    5.074</td> <td> 0.000</td> <td>  144.877</td> <td>  327.343</td>
</tr>
<tr>
  <th>x3</th> <td> -205.4303</td> <td>   26.434</td> <td>   -7.771</td> <td> 0.000</td> <td> -257.255</td> <td> -153.605</td>
</tr>
<tr>
  <th>x4</th> <td>   60.4636</td> <td>   28.413</td> <td>    2.128</td> <td> 0.033</td> <td>    4.758</td> <td>  116.169</td>
</tr>
<tr>
  <th>x5</th> <td>   45.5513</td> <td>   12.741</td> <td>    3.575</td> <td> 0.000</td> <td>   20.573</td> <td>   70.530</td>
</tr>
<tr>
  <th>x6</th> <td>   67.4951</td> <td>   25.492</td> <td>    2.648</td> <td> 0.008</td> <td>   17.518</td> <td>  117.473</td>
</tr>
<tr>
  <th>x7</th> <td>   45.5513</td> <td>   12.741</td> <td>    3.575</td> <td> 0.000</td> <td>   20.573</td> <td>   70.530</td>
</tr>
<tr>
  <th>x8</th> <td>   57.0541</td> <td>   27.045</td> <td>    2.110</td> <td> 0.035</td> <td>    4.032</td> <td>  110.077</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>838.014</td> <th>  Durbin-Watson:     </th> <td>   0.117</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>2441.811</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.049</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 6.118</td>  <th>  Cond. No.          </th> <td>7.76e+15</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The smallest eigenvalue is 1.57e-28. This might indicate that there are<br/>strong multicollinearity problems or that the design matrix is singular.



There seems to be significant in general, but we're still getting the 15 R2 meaning that  
we're not explaining a lot of the Y variance with our X.  
This could mean that the largest explanation is in the categorical variables

### Variable Importances

One method we can use to find variable importances in our dataset is using a different model  
In this case we can use Random Forest to see which variables seem most important to the price


```python
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor

from sklearn.model_selection import train_test_split
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4148 entries, 0 to 4147
    Data columns (total 24 columns):
    bathrooms                4148 non-null int64
    detailedType_typology    4148 non-null object
    distance                 4148 non-null int64
    district                 4148 non-null object
    exterior                 4148 non-null bool
    floor                    4148 non-null int64
    has360                   4148 non-null bool
    has3DTour                4148 non-null bool
    hasLift                  4148 non-null bool
    hasPlan                  4148 non-null bool
    hasVideo                 4148 non-null bool
    latitude                 4148 non-null float64
    longitude                4148 non-null float64
    municipality             4148 non-null object
    numPhotos                4148 non-null int64
    hasParkingSpace          4148 non-null bool
    price                    4148 non-null float64
    priceByArea              4148 non-null float64
    propertyCode             4148 non-null float64
    propertyType             4148 non-null object
    rooms                    4148 non-null int64
    showAddress              4148 non-null bool
    size                     4148 non-null float64
    status                   4148 non-null object
    dtypes: bool(8), float64(6), int64(5), object(5)
    memory usage: 551.0+ KB
    


```python
feats = df.columns
```


```python
X = df.copy()
```


```python
X.columns
```




    Index(['bathrooms', 'detailedType_typology', 'distance', 'district',
           'exterior', 'floor', 'has360', 'has3DTour', 'hasLift', 'hasPlan',
           'hasVideo', 'latitude', 'longitude', 'municipality', 'numPhotos',
           'hasParkingSpace', 'price', 'priceByArea', 'propertyCode',
           'propertyType', 'rooms', 'showAddress', 'size', 'status'],
          dtype='object')




```python
X.drop(['latitude','longitude','price','priceByArea','propertyCode','detailedType_typology', 'showAddress'], axis=1, inplace=True)
```


```python
y = df['price']
```


```python
X = pd.get_dummies(X)
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.32, random_state=101)
```


```python
rfr = RandomForestRegressor()
rfr.fit(X_train,y_train)
print("Train: ",rfr.score(X_train,y_train))
print("Test: ",rfr.score(X_test,y_test))
```

    Train:  0.9651517481891312
    Test:  0.8290800242277729
    


```python
gbr = GradientBoostingRegressor(n_estimators=200)
gbr.fit(X_train,y_train)
print("Train: ",gbr.score(X_train,y_train))
print("Test: ",gbr.score(X_test,y_test))
```

    Train:  0.8760118547910274
    Test:  0.8446767651624798
    


```python
def rf_feat_importance(m, df):
    return pd.DataFrame({'cols': df.columns,'imp' :
    m.feature_importances_}).sort_values('imp',ascending = False)
```


```python
fi = rf_feat_importance(rfr, X)
fi[:10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cols</th>
      <th>imp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12</th>
      <td>size</td>
      <td>0.684596</td>
    </tr>
    <tr>
      <th>1</th>
      <td>distance</td>
      <td>0.115815</td>
    </tr>
    <tr>
      <th>9</th>
      <td>numPhotos</td>
      <td>0.041142</td>
    </tr>
    <tr>
      <th>0</th>
      <td>bathrooms</td>
      <td>0.028986</td>
    </tr>
    <tr>
      <th>3</th>
      <td>floor</td>
      <td>0.021540</td>
    </tr>
    <tr>
      <th>4</th>
      <td>has360</td>
      <td>0.012062</td>
    </tr>
    <tr>
      <th>7</th>
      <td>hasPlan</td>
      <td>0.011795</td>
    </tr>
    <tr>
      <th>54</th>
      <td>district_Salamanca</td>
      <td>0.011428</td>
    </tr>
    <tr>
      <th>11</th>
      <td>rooms</td>
      <td>0.010786</td>
    </tr>
    <tr>
      <th>21</th>
      <td>district_Chamartín</td>
      <td>0.007974</td>
    </tr>
  </tbody>
</table>
</div>




```python
fi = rf_feat_importance(gbr, X)
fi[:10]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cols</th>
      <th>imp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12</th>
      <td>size</td>
      <td>0.726602</td>
    </tr>
    <tr>
      <th>1</th>
      <td>distance</td>
      <td>0.113933</td>
    </tr>
    <tr>
      <th>0</th>
      <td>bathrooms</td>
      <td>0.057397</td>
    </tr>
    <tr>
      <th>9</th>
      <td>numPhotos</td>
      <td>0.019247</td>
    </tr>
    <tr>
      <th>54</th>
      <td>district_Salamanca</td>
      <td>0.012516</td>
    </tr>
    <tr>
      <th>7</th>
      <td>hasPlan</td>
      <td>0.012164</td>
    </tr>
    <tr>
      <th>4</th>
      <td>has360</td>
      <td>0.009536</td>
    </tr>
    <tr>
      <th>21</th>
      <td>district_Chamartín</td>
      <td>0.008145</td>
    </tr>
    <tr>
      <th>11</th>
      <td>rooms</td>
      <td>0.005917</td>
    </tr>
    <tr>
      <th>85</th>
      <td>municipality_La Moraleja</td>
      <td>0.003539</td>
    </tr>
  </tbody>
</table>
</div>



From these experiments, we can see that size seems to be the most important metric for this algorithm.  
Same with distance, bathroom, num Photos, but then Districts start appearing. 

We'll run the Linear Model with the dummy variables for district.However at this point the number of features  
has exploded so we might not be able to interpret the model that easily

### Back to Linear Model


```python
feats = scaler.fit_transform(X)
model = OLS(target,feats)
results = model.fit()
results.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>          <td>price</td>      <th>  R-squared:         </th> <td>   0.168</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.150</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   9.425</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sat, 22 Dec 2018</td> <th>  Prob (F-statistic):</th> <td>5.60e-107</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:14:36</td>     <th>  Log-Likelihood:    </th> <td> -36523.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  4148</td>      <th>  AIC:               </th> <td>7.322e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  4061</td>      <th>  BIC:               </th> <td>7.377e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    87</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
    <td></td>      <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th>   <td>  205.4592</td> <td>   51.061</td> <td>    4.024</td> <td> 0.000</td> <td>  105.351</td> <td>  305.567</td>
</tr>
<tr>
  <th>x2</th>   <td> -221.5089</td> <td>   82.686</td> <td>   -2.679</td> <td> 0.007</td> <td> -383.619</td> <td>  -59.399</td>
</tr>
<tr>
  <th>x3</th>   <td>   41.8133</td> <td>   29.226</td> <td>    1.431</td> <td> 0.153</td> <td>  -15.486</td> <td>   99.113</td>
</tr>
<tr>
  <th>x4</th>   <td>   -2.2624</td> <td>   28.180</td> <td>   -0.080</td> <td> 0.936</td> <td>  -57.511</td> <td>   52.986</td>
</tr>
<tr>
  <th>x5</th>   <td>   60.9989</td> <td>   25.859</td> <td>    2.359</td> <td> 0.018</td> <td>   10.302</td> <td>  111.696</td>
</tr>
<tr>
  <th>x6</th>   <td>   -5.7410</td> <td>   25.814</td> <td>   -0.222</td> <td> 0.824</td> <td>  -56.351</td> <td>   44.869</td>
</tr>
<tr>
  <th>x7</th>   <td>   37.3628</td> <td>   30.641</td> <td>    1.219</td> <td> 0.223</td> <td>  -22.710</td> <td>   97.435</td>
</tr>
<tr>
  <th>x8</th>   <td>   59.8899</td> <td>   31.918</td> <td>    1.876</td> <td> 0.061</td> <td>   -2.686</td> <td>  122.466</td>
</tr>
<tr>
  <th>x9</th>   <td>  -23.7765</td> <td>   30.235</td> <td>   -0.786</td> <td> 0.432</td> <td>  -83.054</td> <td>   35.501</td>
</tr>
<tr>
  <th>x10</th>  <td>   47.2773</td> <td>   29.019</td> <td>    1.629</td> <td> 0.103</td> <td>   -9.616</td> <td>  104.171</td>
</tr>
<tr>
  <th>x11</th>  <td>   46.5078</td> <td>   32.931</td> <td>    1.412</td> <td> 0.158</td> <td>  -18.055</td> <td>  111.071</td>
</tr>
<tr>
  <th>x12</th>  <td>   44.6386</td> <td>   48.942</td> <td>    0.912</td> <td> 0.362</td> <td>  -51.314</td> <td>  140.591</td>
</tr>
<tr>
  <th>x13</th>  <td>  419.6552</td> <td>   57.875</td> <td>    7.251</td> <td> 0.000</td> <td>  306.189</td> <td>  533.122</td>
</tr>
<tr>
  <th>x14</th>  <td>    8.1160</td> <td>   22.397</td> <td>    0.362</td> <td> 0.717</td> <td>  -35.795</td> <td>   52.027</td>
</tr>
<tr>
  <th>x15</th>  <td>  -48.1808</td> <td>   25.985</td> <td>   -1.854</td> <td> 0.064</td> <td>  -99.126</td> <td>    2.765</td>
</tr>
<tr>
  <th>x16</th>  <td>   -5.6804</td> <td>   24.995</td> <td>   -0.227</td> <td> 0.820</td> <td>  -54.684</td> <td>   43.323</td>
</tr>
<tr>
  <th>x17</th>  <td>    0.4391</td> <td>   28.448</td> <td>    0.015</td> <td> 0.988</td> <td>  -55.335</td> <td>   56.213</td>
</tr>
<tr>
  <th>x18</th>  <td>    4.5490</td> <td>   24.997</td> <td>    0.182</td> <td> 0.856</td> <td>  -44.458</td> <td>   53.556</td>
</tr>
<tr>
  <th>x19</th>  <td>  -48.1944</td> <td>   25.156</td> <td>   -1.916</td> <td> 0.055</td> <td>  -97.514</td> <td>    1.125</td>
</tr>
<tr>
  <th>x20</th>  <td>    4.4471</td> <td>   33.557</td> <td>    0.133</td> <td> 0.895</td> <td>  -61.343</td> <td>   70.237</td>
</tr>
<tr>
  <th>x21</th>  <td>  -17.2766</td> <td>   36.548</td> <td>   -0.473</td> <td> 0.636</td> <td>  -88.930</td> <td>   54.377</td>
</tr>
<tr>
  <th>x22</th>  <td>   35.9604</td> <td>   23.917</td> <td>    1.504</td> <td> 0.133</td> <td>  -10.929</td> <td>   82.850</td>
</tr>
<tr>
  <th>x23</th>  <td>   24.1234</td> <td>   26.916</td> <td>    0.896</td> <td> 0.370</td> <td>  -28.647</td> <td>   76.894</td>
</tr>
<tr>
  <th>x24</th>  <td>  -31.0594</td> <td>   25.758</td> <td>   -1.206</td> <td> 0.228</td> <td>  -81.559</td> <td>   19.440</td>
</tr>
<tr>
  <th>x25</th>  <td>   -3.0022</td> <td>   16.967</td> <td>   -0.177</td> <td> 0.860</td> <td>  -36.267</td> <td>   30.263</td>
</tr>
<tr>
  <th>x26</th>  <td>    1.7570</td> <td>   21.968</td> <td>    0.080</td> <td> 0.936</td> <td>  -41.311</td> <td>   44.825</td>
</tr>
<tr>
  <th>x27</th>  <td>  -11.9293</td> <td>   23.948</td> <td>   -0.498</td> <td> 0.618</td> <td>  -58.880</td> <td>   35.021</td>
</tr>
<tr>
  <th>x28</th>  <td>   -5.0973</td> <td>   31.070</td> <td>   -0.164</td> <td> 0.870</td> <td>  -66.012</td> <td>   55.818</td>
</tr>
<tr>
  <th>x29</th>  <td>   -4.1945</td> <td>   21.931</td> <td>   -0.191</td> <td> 0.848</td> <td>  -47.191</td> <td>   38.802</td>
</tr>
<tr>
  <th>x30</th>  <td>   25.6593</td> <td>   22.776</td> <td>    1.127</td> <td> 0.260</td> <td>  -18.994</td> <td>   70.313</td>
</tr>
<tr>
  <th>x31</th>  <td>   29.5640</td> <td>   18.618</td> <td>    1.588</td> <td> 0.112</td> <td>   -6.937</td> <td>   66.065</td>
</tr>
<tr>
  <th>x32</th>  <td>   -6.1367</td> <td>   21.580</td> <td>   -0.284</td> <td> 0.776</td> <td>  -48.445</td> <td>   36.171</td>
</tr>
<tr>
  <th>x33</th>  <td>  -19.1467</td> <td>   32.373</td> <td>   -0.591</td> <td> 0.554</td> <td>  -82.616</td> <td>   44.323</td>
</tr>
<tr>
  <th>x34</th>  <td>    0.7062</td> <td>   12.845</td> <td>    0.055</td> <td> 0.956</td> <td>  -24.476</td> <td>   25.889</td>
</tr>
<tr>
  <th>x35</th>  <td>    2.7233</td> <td>   22.512</td> <td>    0.121</td> <td> 0.904</td> <td>  -41.413</td> <td>   46.860</td>
</tr>
<tr>
  <th>x36</th>  <td>   -6.6724</td> <td>   24.531</td> <td>   -0.272</td> <td> 0.786</td> <td>  -54.767</td> <td>   41.422</td>
</tr>
<tr>
  <th>x37</th>  <td>    6.7817</td> <td>   28.574</td> <td>    0.237</td> <td> 0.812</td> <td>  -49.239</td> <td>   62.802</td>
</tr>
<tr>
  <th>x38</th>  <td>   -5.0060</td> <td>   33.833</td> <td>   -0.148</td> <td> 0.882</td> <td>  -71.336</td> <td>   61.325</td>
</tr>
<tr>
  <th>x39</th>  <td>    4.1834</td> <td>   24.558</td> <td>    0.170</td> <td> 0.865</td> <td>  -43.965</td> <td>   52.331</td>
</tr>
<tr>
  <th>x40</th>  <td>    0.4743</td> <td>   23.792</td> <td>    0.020</td> <td> 0.984</td> <td>  -46.172</td> <td>   47.120</td>
</tr>
<tr>
  <th>x41</th>  <td>   -1.9667</td> <td>   28.420</td> <td>   -0.069</td> <td> 0.945</td> <td>  -57.685</td> <td>   53.752</td>
</tr>
<tr>
  <th>x42</th>  <td>  -42.6482</td> <td>   25.309</td> <td>   -1.685</td> <td> 0.092</td> <td>  -92.268</td> <td>    6.972</td>
</tr>
<tr>
  <th>x43</th>  <td>  -14.0666</td> <td>   31.188</td> <td>   -0.451</td> <td> 0.652</td> <td>  -75.212</td> <td>   47.079</td>
</tr>
<tr>
  <th>x44</th>  <td>   -0.8344</td> <td>   24.144</td> <td>   -0.035</td> <td> 0.972</td> <td>  -48.170</td> <td>   46.501</td>
</tr>
<tr>
  <th>x45</th>  <td>  -34.4332</td> <td>   25.439</td> <td>   -1.354</td> <td> 0.176</td> <td>  -84.308</td> <td>   15.441</td>
</tr>
<tr>
  <th>x46</th>  <td>    1.1207</td> <td>   24.626</td> <td>    0.046</td> <td> 0.964</td> <td>  -47.160</td> <td>   49.402</td>
</tr>
<tr>
  <th>x47</th>  <td>  -24.4176</td> <td>   40.887</td> <td>   -0.597</td> <td> 0.550</td> <td> -104.578</td> <td>   55.743</td>
</tr>
<tr>
  <th>x48</th>  <td>   -2.7609</td> <td>   28.748</td> <td>   -0.096</td> <td> 0.923</td> <td>  -59.122</td> <td>   53.600</td>
</tr>
<tr>
  <th>x49</th>  <td>   -5.9971</td> <td>   27.128</td> <td>   -0.221</td> <td> 0.825</td> <td>  -59.182</td> <td>   47.188</td>
</tr>
<tr>
  <th>x50</th>  <td>  -12.4050</td> <td>   25.067</td> <td>   -0.495</td> <td> 0.621</td> <td>  -61.550</td> <td>   36.740</td>
</tr>
<tr>
  <th>x51</th>  <td>   -6.4747</td> <td>   31.829</td> <td>   -0.203</td> <td> 0.839</td> <td>  -68.876</td> <td>   55.927</td>
</tr>
<tr>
  <th>x52</th>  <td>  -27.1864</td> <td>   25.389</td> <td>   -1.071</td> <td> 0.284</td> <td>  -76.962</td> <td>   22.589</td>
</tr>
<tr>
  <th>x53</th>  <td>    0.8736</td> <td>   25.585</td> <td>    0.034</td> <td> 0.973</td> <td>  -49.287</td> <td>   51.034</td>
</tr>
<tr>
  <th>x54</th>  <td>    4.0600</td> <td>   22.905</td> <td>    0.177</td> <td> 0.859</td> <td>  -40.846</td> <td>   48.966</td>
</tr>
<tr>
  <th>x55</th>  <td>   97.9534</td> <td>   25.809</td> <td>    3.795</td> <td> 0.000</td> <td>   47.354</td> <td>  148.553</td>
</tr>
<tr>
  <th>x56</th>  <td>  -11.6577</td> <td>   28.962</td> <td>   -0.403</td> <td> 0.687</td> <td>  -68.438</td> <td>   45.123</td>
</tr>
<tr>
  <th>x57</th>  <td>   -0.6736</td> <td>   35.836</td> <td>   -0.019</td> <td> 0.985</td> <td>  -70.933</td> <td>   69.585</td>
</tr>
<tr>
  <th>x58</th>  <td>   -0.4243</td> <td>   23.518</td> <td>   -0.018</td> <td> 0.986</td> <td>  -46.533</td> <td>   45.684</td>
</tr>
<tr>
  <th>x59</th>  <td>  -16.3895</td> <td>   24.558</td> <td>   -0.667</td> <td> 0.505</td> <td>  -64.537</td> <td>   31.758</td>
</tr>
<tr>
  <th>x60</th>  <td>    1.6430</td> <td>   24.161</td> <td>    0.068</td> <td> 0.946</td> <td>  -45.726</td> <td>   49.011</td>
</tr>
<tr>
  <th>x61</th>  <td>  -32.2506</td> <td>   37.380</td> <td>   -0.863</td> <td> 0.388</td> <td> -105.536</td> <td>   41.035</td>
</tr>
<tr>
  <th>x62</th>  <td>   14.5523</td> <td>   25.509</td> <td>    0.570</td> <td> 0.568</td> <td>  -35.460</td> <td>   64.564</td>
</tr>
<tr>
  <th>x63</th>  <td>  -37.6789</td> <td>   25.243</td> <td>   -1.493</td> <td> 0.136</td> <td>  -87.169</td> <td>   11.811</td>
</tr>
<tr>
  <th>x64</th>  <td>   14.8909</td> <td>   23.173</td> <td>    0.643</td> <td> 0.521</td> <td>  -30.541</td> <td>   60.323</td>
</tr>
<tr>
  <th>x65</th>  <td>  -16.7089</td> <td>   49.905</td> <td>   -0.335</td> <td> 0.738</td> <td> -114.550</td> <td>   81.132</td>
</tr>
<tr>
  <th>x66</th>  <td>  -10.4519</td> <td>   33.527</td> <td>   -0.312</td> <td> 0.755</td> <td>  -76.182</td> <td>   55.278</td>
</tr>
<tr>
  <th>x67</th>  <td>   -7.7539</td> <td>   31.947</td> <td>   -0.243</td> <td> 0.808</td> <td>  -70.388</td> <td>   54.880</td>
</tr>
<tr>
  <th>x68</th>  <td>    2.2415</td> <td>   21.997</td> <td>    0.102</td> <td> 0.919</td> <td>  -40.884</td> <td>   45.367</td>
</tr>
<tr>
  <th>x69</th>  <td>  -19.5528</td> <td>   26.095</td> <td>   -0.749</td> <td> 0.454</td> <td>  -70.713</td> <td>   31.607</td>
</tr>
<tr>
  <th>x70</th>  <td>   -8.4383</td> <td>   28.920</td> <td>   -0.292</td> <td> 0.770</td> <td>  -65.137</td> <td>   48.260</td>
</tr>
<tr>
  <th>x71</th>  <td>  -19.8399</td> <td>   25.948</td> <td>   -0.765</td> <td> 0.445</td> <td>  -70.712</td> <td>   31.032</td>
</tr>
<tr>
  <th>x72</th>  <td>   -4.3368</td> <td>   12.893</td> <td>   -0.336</td> <td> 0.737</td> <td>  -29.614</td> <td>   20.940</td>
</tr>
<tr>
  <th>x73</th>  <td>    0.1557</td> <td>   35.855</td> <td>    0.004</td> <td> 0.997</td> <td>  -70.140</td> <td>   70.451</td>
</tr>
<tr>
  <th>x74</th>  <td>   -4.6726</td> <td>   23.476</td> <td>   -0.199</td> <td> 0.842</td> <td>  -50.698</td> <td>   41.353</td>
</tr>
<tr>
  <th>x75</th>  <td>    1.5359</td> <td>   26.378</td> <td>    0.058</td> <td> 0.954</td> <td>  -50.180</td> <td>   53.252</td>
</tr>
<tr>
  <th>x76</th>  <td>  -17.1841</td> <td>   24.691</td> <td>   -0.696</td> <td> 0.486</td> <td>  -65.592</td> <td>   31.224</td>
</tr>
<tr>
  <th>x77</th>  <td>   19.7587</td> <td>   28.457</td> <td>    0.694</td> <td> 0.488</td> <td>  -36.033</td> <td>   75.550</td>
</tr>
<tr>
  <th>x78</th>  <td>  -20.4604</td> <td>   23.296</td> <td>   -0.878</td> <td> 0.380</td> <td>  -66.133</td> <td>   25.213</td>
</tr>
<tr>
  <th>x79</th>  <td>   -9.5994</td> <td>   24.520</td> <td>   -0.391</td> <td> 0.695</td> <td>  -57.671</td> <td>   38.473</td>
</tr>
<tr>
  <th>x80</th>  <td>    3.2199</td> <td>   24.642</td> <td>    0.131</td> <td> 0.896</td> <td>  -45.092</td> <td>   51.531</td>
</tr>
<tr>
  <th>x81</th>  <td>    8.1706</td> <td>   13.458</td> <td>    0.607</td> <td> 0.544</td> <td>  -18.214</td> <td>   34.556</td>
</tr>
<tr>
  <th>x82</th>  <td>   13.3744</td> <td>   51.967</td> <td>    0.257</td> <td> 0.797</td> <td>  -88.510</td> <td>  115.259</td>
</tr>
<tr>
  <th>x83</th>  <td>   13.6905</td> <td>   61.630</td> <td>    0.222</td> <td> 0.824</td> <td> -107.138</td> <td>  134.519</td>
</tr>
<tr>
  <th>x84</th>  <td>   -0.1131</td> <td>   12.766</td> <td>   -0.009</td> <td> 0.993</td> <td>  -25.142</td> <td>   24.915</td>
</tr>
<tr>
  <th>x85</th>  <td>   -4.9602</td> <td>   13.200</td> <td>   -0.376</td> <td> 0.707</td> <td>  -30.840</td> <td>   20.920</td>
</tr>
<tr>
  <th>x86</th>  <td>   36.4178</td> <td>   13.982</td> <td>    2.605</td> <td> 0.009</td> <td>    9.005</td> <td>   63.831</td>
</tr>
<tr>
  <th>x87</th>  <td>   -4.3368</td> <td>   12.893</td> <td>   -0.336</td> <td> 0.737</td> <td>  -29.614</td> <td>   20.940</td>
</tr>
<tr>
  <th>x88</th>  <td>   -5.7289</td> <td>   55.418</td> <td>   -0.103</td> <td> 0.918</td> <td> -114.378</td> <td>  102.920</td>
</tr>
<tr>
  <th>x89</th>  <td>  -12.4237</td> <td>   26.040</td> <td>   -0.477</td> <td> 0.633</td> <td>  -63.477</td> <td>   38.629</td>
</tr>
<tr>
  <th>x90</th>  <td>    1.6291</td> <td>   30.509</td> <td>    0.053</td> <td> 0.957</td> <td>  -58.186</td> <td>   61.444</td>
</tr>
<tr>
  <th>x91</th>  <td>  -15.8643</td> <td>   13.297</td> <td>   -1.193</td> <td> 0.233</td> <td>  -41.934</td> <td>   10.205</td>
</tr>
<tr>
  <th>x92</th>  <td>   -0.5695</td> <td>   12.929</td> <td>   -0.044</td> <td> 0.965</td> <td>  -25.918</td> <td>   24.778</td>
</tr>
<tr>
  <th>x93</th>  <td>    0.7062</td> <td>   12.845</td> <td>    0.055</td> <td> 0.956</td> <td>  -24.476</td> <td>   25.889</td>
</tr>
<tr>
  <th>x94</th>  <td>  -34.3182</td> <td>   34.718</td> <td>   -0.988</td> <td> 0.323</td> <td> -102.385</td> <td>   33.748</td>
</tr>
<tr>
  <th>x95</th>  <td>   -1.6480</td> <td>   23.948</td> <td>   -0.069</td> <td> 0.945</td> <td>  -48.599</td> <td>   45.303</td>
</tr>
<tr>
  <th>x96</th>  <td>    3.8175</td> <td>   16.168</td> <td>    0.236</td> <td> 0.813</td> <td>  -27.880</td> <td>   35.515</td>
</tr>
<tr>
  <th>x97</th>  <td>   23.4454</td> <td>   22.284</td> <td>    1.052</td> <td> 0.293</td> <td>  -20.244</td> <td>   67.135</td>
</tr>
<tr>
  <th>x98</th>  <td>   -6.2919</td> <td>   25.285</td> <td>   -0.249</td> <td> 0.803</td> <td>  -55.865</td> <td>   43.281</td>
</tr>
<tr>
  <th>x99</th>  <td>    1.5768</td> <td>   12.909</td> <td>    0.122</td> <td> 0.903</td> <td>  -23.733</td> <td>   26.886</td>
</tr>
<tr>
  <th>x100</th> <td>   -1.5768</td> <td>   12.909</td> <td>   -0.122</td> <td> 0.903</td> <td>  -26.886</td> <td>   23.733</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>1051.243</td> <th>  Durbin-Watson:     </th> <td>   0.093</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>3994.348</td>
</tr>
<tr>
  <th>Skew:</th>           <td> 1.215</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>       <td> 7.148</td>  <th>  Cond. No.          </th> <td>4.42e+16</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The smallest eigenvalue is 1.01e-29. This might indicate that there are<br/>strong multicollinearity problems or that the design matrix is singular.




```python
for i, col in enumerate(X.columns):
    if col == 'district_Salamanca':
        print(i)
```

    54
    

We can see that we have a lot of districts that are not significant at all, but at the same time some districts seem to be very significant like being ins Salamanca (feature 55) has an almost 100 Euro premium in rent with almost 0 p-value

### Conclusions

We have concluded that as we suspected. The size of the apartment, the ammount of rooms, bathrooms are positively  
correlated to the price of rent, and are also very significant to it. The district is alos important, although  
some districts like Salamanca command a premium while others are less significant. This is logical  
as some districts won't affect the price as they are not special. That's why those dummy variables seem unimportant.

As we care more about the predictive power of our model, than the inference we get from it.  We will swith to using  
sklearns Linear Models to try and get a better model with a higher R^2 to implement.

## Machine Learning


```python
from sklearn.linear_model import Lasso, Ridge, LinearRegression
```


```python
X2 = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X2, y, test_size=0.3, random_state=101)
```


```python
m1 = LinearRegression()
m1.fit(X_train, y_train)
print("Train: ", m1.score(X_train, y_train))
print("Test: ", m1.score(X_test, y_test))
```

    Train:  0.786660537558906
    Test:  -5.849476790004094e+26
    

Well that is weird, this could be because off all the insignificant and dummy variables. We can add some regularization to our model  
We can start with L2 regularization with Ridge Regression, and if it's not enough we can go for L1 reg with LASSO


```python
m2 = Ridge()
m2.fit(X_train, y_train)
print("Train: ", m2.score(X_train, y_train))
print("Test: ", m2.score(X_test, y_test))

m2_coef = pd.DataFrame(m2.coef_, index=X.columns, columns=['coef'])
```

    Train:  0.7884826245934231
    Test:  0.7929662322250918
    

This seems much better.  We can also check the coefficients


```python
m2_coef[m2_coef['coef'] > 10].sort_values(by='coef', ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>coef</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>size</th>
      <td>399.740743</td>
    </tr>
    <tr>
      <th>bathrooms</th>
      <td>213.527895</td>
    </tr>
    <tr>
      <th>district_Salamanca</th>
      <td>88.064063</td>
    </tr>
    <tr>
      <th>hasPlan</th>
      <td>70.350010</td>
    </tr>
    <tr>
      <th>has360</th>
      <td>54.542340</td>
    </tr>
    <tr>
      <th>rooms</th>
      <td>52.904398</td>
    </tr>
    <tr>
      <th>numPhotos</th>
      <td>43.116144</td>
    </tr>
    <tr>
      <th>hasParkingSpace</th>
      <td>42.934122</td>
    </tr>
    <tr>
      <th>hasLift</th>
      <td>41.747064</td>
    </tr>
    <tr>
      <th>municipality_La Moraleja</th>
      <td>37.461836</td>
    </tr>
    <tr>
      <th>district_Chamartín</th>
      <td>35.596708</td>
    </tr>
    <tr>
      <th>exterior</th>
      <td>35.131653</td>
    </tr>
    <tr>
      <th>district_Encinar de los Reyes</th>
      <td>29.961159</td>
    </tr>
    <tr>
      <th>district_El Soto de la Moraleja</th>
      <td>27.286602</td>
    </tr>
    <tr>
      <th>propertyType_penthouse</th>
      <td>26.880869</td>
    </tr>
    <tr>
      <th>district_Chamberí</th>
      <td>19.967412</td>
    </tr>
    <tr>
      <th>district_Zona norte</th>
      <td>18.319111</td>
    </tr>
    <tr>
      <th>district_Zona Monte el Pilar</th>
      <td>17.127174</td>
    </tr>
    <tr>
      <th>district_Urbanizaciones</th>
      <td>15.101617</td>
    </tr>
    <tr>
      <th>municipality_Boadilla del Monte</th>
      <td>14.723845</td>
    </tr>
    <tr>
      <th>municipality_Alcorcón</th>
      <td>14.121536</td>
    </tr>
    <tr>
      <th>district_Retiro</th>
      <td>10.380535</td>
    </tr>
  </tbody>
</table>
</div>



These coefficients are all from a Scaled Variable, that's why Size seems too big. This can only be interpreted  
as biggest price "movers"


```python
m3 = Lasso()
m3.fit(X_train, y_train)
print("Train: ", m3.score(X_train, y_train))
print("Test: ", m3.score(X_test, y_test))

m3_coef = pd.DataFrame(m3.coef_, index=X.columns, columns=['coef'])
```

    Train:  0.7883007135327403
    Test:  0.794321359881087
    


```python
m3_coef[m3_coef['coef'] > 10].sort_values(by='coef', ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>coef</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>size</th>
      <td>401.092479</td>
    </tr>
    <tr>
      <th>bathrooms</th>
      <td>212.619603</td>
    </tr>
    <tr>
      <th>district_Salamanca</th>
      <td>100.110465</td>
    </tr>
    <tr>
      <th>municipality_La Moraleja</th>
      <td>79.810637</td>
    </tr>
    <tr>
      <th>hasPlan</th>
      <td>68.954368</td>
    </tr>
    <tr>
      <th>has360</th>
      <td>53.861210</td>
    </tr>
    <tr>
      <th>rooms</th>
      <td>51.793921</td>
    </tr>
    <tr>
      <th>district_Chamartín</th>
      <td>43.269687</td>
    </tr>
    <tr>
      <th>numPhotos</th>
      <td>42.832062</td>
    </tr>
    <tr>
      <th>hasLift</th>
      <td>42.246458</td>
    </tr>
    <tr>
      <th>hasParkingSpace</th>
      <td>40.222385</td>
    </tr>
    <tr>
      <th>exterior</th>
      <td>34.505599</td>
    </tr>
    <tr>
      <th>district_Chamberí</th>
      <td>29.477734</td>
    </tr>
    <tr>
      <th>propertyType_penthouse</th>
      <td>27.225086</td>
    </tr>
    <tr>
      <th>district_Retiro</th>
      <td>17.374733</td>
    </tr>
    <tr>
      <th>district_Zona norte</th>
      <td>16.944472</td>
    </tr>
    <tr>
      <th>district_Zona Monte el Pilar</th>
      <td>15.378554</td>
    </tr>
    <tr>
      <th>district_Urbanizaciones</th>
      <td>14.721274</td>
    </tr>
    <tr>
      <th>district_Alcobendas Centro</th>
      <td>11.703159</td>
    </tr>
    <tr>
      <th>district_Moncloa</th>
      <td>10.659123</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(sum(m3_coef['coef'] > 0), "coefficients not made '0' by model")
```

    40 coefficients not made '0' by model
    

The LASSO model made 60 coefficients 0, reducing the chances of the model being wrong because of insignificant variables


```python
print("LinReg Score: ", m1.score(X_test, y_test))
print("Ridge Score: ", m2.score(X_test, y_test))
print("Lasso Score: ", m3.score(X_test, y_test))
```

    LinReg Score:  -5.849476790004094e+26
    Ridge Score:  0.7929662322250918
    Lasso Score:  0.794321359881087
    

As Lasso Uses less variables and gave us marginally a better score, wwe can then optimize for this one


```python
loss_values = [0.000001,0.00001,0.0001,0.001,0.01,0.1,1,10]
train_score = []
test_score = []

for i in loss_values:
    m = Lasso(alpha=i)
    m.fit(X_train, y_train)
    train_score.append(m.score(X_train, y_train))
    test_score.append(m.score(X_test, y_test))

models_list = pd.DataFrame(data={'Loss':loss_values, 'Train':train_score, 'Test': test_score})
models_list
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Loss</th>
      <th>Train</th>
      <th>Test</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000001</td>
      <td>0.788483</td>
      <td>0.793486</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.000010</td>
      <td>0.788483</td>
      <td>0.793486</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.000100</td>
      <td>0.788483</td>
      <td>0.793481</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.001000</td>
      <td>0.788483</td>
      <td>0.793414</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.010000</td>
      <td>0.788483</td>
      <td>0.793293</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.100000</td>
      <td>0.788481</td>
      <td>0.792966</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.000000</td>
      <td>0.788301</td>
      <td>0.794321</td>
    </tr>
    <tr>
      <th>7</th>
      <td>10.000000</td>
      <td>0.780804</td>
      <td>0.790248</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.plot(models_list['Loss'], models_list['Test'])
plt.xscale('log')
```


![png](output_116_0.png)


Seems like the best linear model for this dataset is the Lasso Regression algorithm with an alpha of 1 (default)

# Final Conclusions

We found what the main drivers for the price is, and we found that in the case of districts, only some were important and not the other ones.  We also had to decide between interpretability getting 15% explained variance in Y with that set. Compared with Predictions power which using sklearn's linear methods got close to 80% in R squared. 

As next steps, we will reproduce this model in Dataiku so that we can use the flow to create a train/val/test dataset. And then  create some new features with the model as predcited price so we can use residuals to figure out if a listing price is a good deal or not
